<?php
include 'admin/config.php';
session_destroy();
?>
<script>
window.location = 'index.php';
</script>