<?php include 'header.php' ?>
<!-- Breadcrumb Section Begin -->
<div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i>Menu</a>
                        <span>Tentang Kami</span>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="jumbotron">
            <p>
           <h3> Selamat Datang di Website Zoepy Petshop</h3>
            Zoepy Petshop Merupakan salah satu Petshop Terlengkap yang ada di derah Yogyakarta terpatnya di  Jalan.Krodan no.7, Krodan, Maguwoharjo, Kecamatan depok, Kabupaten Sleman, Daerah Istimewa Yogyakarta. 
           Petshop ini berdiri sejak tahun 2020.Zoepy memberikan pelayanan yang terbaik untuk Anda, dengan pekerja yang profesional dan yang pastinya berpengalaman di bidangnya masing-masing. 
           Zoepy hadir untuk Anda yang merasa kerepotan dengan masalah perawatan untuk hewan peliharaan Anda. 
           Mungkin sibuk bekerja atau yang lainnya, dan untuk harga produk dan layanan yang masih terjangkau untuk kalangan masyarakat. 
           Kualitas produk yang kami sediakan juga sangat terjamin. melayani berbagai macam kebutuhan untuk hewan peliharaan Anda. Mulai dari makanan, perawatan, penginapan dan yang lainnya.
            </p>
        </div>
    </div>
<?php include 'footer.php'?>