<?php include 'header.php' ?>
<!-- Breadcrumb Section Begin -->
<div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i>Menu</a>
                        <span>Tentang Kami</span>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="jumbotron">
            <p>
           <h3> Selamat Datang di Sida Rent Car</h3>
            Sida rent Car merupakan salah satu penyewaan mobil terlengkap yang ada di derah Yogyakarta terpatnya di Jalan Paingan,
            Krodan, Maguwoharjo, Kecamatan depok, Kabupaten Sleman, Daerah Istimewa Yogyakarta. Penyewaan mobil ini berdiri sejak 2018.
            Sida rent car memberikan pelayanan yang terbaik untuk Anda, dengan staff yang profesional dan ramah. Sida rent car hadir untuk anda yang sedang memerlukan mobil untuk kebutuhan sementara waktu. Mungkin untuk liburan, kebutuhan acara dll. Harga sewa dan layanan yang masih terjangkau untuk kalangan masyarakat. Kualitas armada yang kami sediakan juga sangat terjamin. 
            melayani berbagai macam kebutuhan kendaraan anda dan menyediakan berbagai model dan jenis mobil. 
            Mulai dari LCGC, MPV, SUV, VIP, Komersil.
            </p>
        </div>
    </div>
<?php include 'footer.php'?>